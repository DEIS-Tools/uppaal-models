#include <uppaal/uppaal.h>
#include <vector>

// Initialize density matrix with binary state string
// (e.g., "01" for |01⟩ or "+-" for |+-⟩)
// rho_size = 1 << 2*N+1, bin = binary state string of length N
extern "C" void InitBinState(double* rho, int rho_size, const char* state) {
    assert(size_t(rho_size) == strlen(state));
    size_t mat_row = 1 << rho_size;
    size_t mat_size = mat_row * mat_row * 2;
    cx_mat res = dmqs::BinaryStringToDensityMatrix(state);
    memmove(rho, res.memptr(), mat_size * sizeof(double));
}

// Apply single-qubit gate to target qubit
extern "C" void ApplyGate(double* rho, int rho_size, int gate, int target) {
    size_t mat_row = 1 << rho_size;
    size_t mat_size = mat_row * mat_row * 2;
    cx_mat in_mat = cx_mat(reinterpret_cast<cx_double*>(rho),
                           mat_row, mat_row, false, true);
    cx_mat res = dmqs::ApplyGate(in_mat, static_cast<u_gate>(gate), target);
    memcpy(rho, res.memptr(), mat_size * sizeof(double));
}

// Apply controlled gate (control -> target)
extern "C" void ApplyCGate(double* rho, int rho_size, int gate, int control,
                            int target) {
    size_t mat_row = 1 << rho_size;
    size_t mat_size = mat_row * mat_row * 2;
    cx_mat in_mat = cx_mat(reinterpret_cast<cx_double*>(rho),
                           mat_row, mat_row, false, true);
    cx_mat res = dmqs::ApplyCGate(in_mat, static_cast<u_gate>(gate), control,
                                  target);
    memcpy(rho, res.memptr(), mat_size * sizeof(double));
}

// Apply custom unitary matrix U (u_size must equal rho_size)
extern "C" void ApplyUnitary(double* rho, int rho_size, double* U,
                              int u_size) {
    if (rho_size != u_size) {
        throw invalid_argument(
            "Density matrix size should be equivilant to unitary. Got " +
            to_string(rho_size) + " and " + to_string(u_size));
    }
    size_t mat_row = 1 << rho_size;
    size_t mat_size = mat_row * mat_row * 2;
    cx_mat in_rho = cx_mat(reinterpret_cast<cx_double*>(rho),
                           mat_row, mat_row, false, true);
    cx_mat in_U = cx_mat(reinterpret_cast<cx_double*>(U),
                         mat_row, mat_row, false, true);
    cx_mat res = dmqs::ApplyGateToDensityMatrix(in_rho, in_U);
    memcpy(rho, res.memptr(), mat_size * sizeof(double));
}

// Partial trace: extract subsystem state into prho
// prho_size = 1 << N*2-1 where N = len(targets)
extern "C" void PartialTrace(double* rho, int rho_size, double* prho,
                              int prho_size, int* targets, int targets_size) {
    if (prho_size != targets_size) {
        throw invalid_argument(
            "The partial density matrix should have the same "
            "size as the number of targets. Got " +
            to_string(rho_size) + " and " + to_string(targets_size));
    }
    size_t mat_row = 1 << rho_size;
    vector<int> t = vector<int>(targets, targets + targets_size);
    cx_mat in_rho = cx_mat(reinterpret_cast<cx_double*>(rho),
                           mat_row, mat_row, false, true);
    cx_mat res = dmqs::PartialTrace(in_rho, t);
    size_t mat_size = ((1 << prho_size) * (1 << prho_size)) << 1;
    memcpy(prho, res.memptr(), mat_size * sizeof(double));
}

// Project target qubit onto basis state (|0⟩ or |1⟩)
extern "C" void BasisProjection(double* rho, int rho_size, int target,
                                 int state) {
    size_t mat_row = 1 << rho_size;
    size_t mat_size = mat_row * mat_row * 2;
    cx_mat in_mat = cx_mat(reinterpret_cast<cx_double*>(rho),
                           mat_row, mat_row, false, true);

    cx_mat res = dmqs::BasisProjection(in_mat, target, state);
    memcpy(rho, res.memptr(), mat_size * sizeof(double));
}

// Project multiple target qubits onto basis state (bitmask)
extern "C" void BasisProjections(double* rho, int rho_size, int* targets,
                                  int targets_size, int state) {
    size_t mat_row = 1 << rho_size;
    size_t mat_size = mat_row * mat_row * 2;
    cx_mat in_mat = cx_mat(reinterpret_cast<cx_double*>(rho),
                           mat_row, mat_row, false, true);
    vector<int> t = vector<int>(targets, targets + targets_size);
    cx_mat res = dmqs::BasisProjections(in_mat, t, state);
    memcpy(rho, res.memptr(), mat_size * sizeof(double));
}

// Measure target qubits and return result (does not collapse state)
// Use UBasisProjections to collapse after measurement
extern "C" int PartialMeasure(double* rho, int rho_size, int* targets,
                               int targets_size, double r) {
    size_t mat_row = 1 << rho_size;
    cx_mat in_mat = cx_mat(reinterpret_cast<cx_double*>(rho),
                           mat_row, mat_row, false, true);
    vector<int> t = vector<int>(targets, targets + targets_size);
    return dmqs::PartialSample(in_mat, t, r);
}

// Measure all qubits and return result (does not collapse state)
extern "C" int MeasureAll(double* rho, int rho_size, double r) {
    size_t mat_row = 1 << rho_size;
    cx_mat in_mat = cx_mat(reinterpret_cast<cx_double*>(rho),
                           mat_row, mat_row, false, true);
    return dmqs::Sample(in_mat, r);
}

// Measure all qubits and return result (does not collapse state)
extern "C" void ResetQubit(double* rho, int rho_size, int qubit) {
    size_t mat_row = 1 << rho_size;
    size_t mat_size = mat_row * mat_row * 2;
    cx_mat in_mat = cx_mat(reinterpret_cast<cx_double*>(rho),
                           mat_row, mat_row, false, true);
    cx_mat res = reset_qubit(in_mat, qubit);
    memcpy(rho, res.memptr(), mat_size * sizeof(double));
}

// Apply amplitude damping and dephasing noise channel on rho as seen
// in: 10.1098/rspa.2008.0439
extern "C" void AmplitudeDampeningAndDephasing(double* rho, int rho_size,
                                                const double* T1,
                                                const double* T2, double t) {
    size_t mat_row = 1 << rho_size;
    size_t mat_size = mat_row * mat_row * 2;
    cx_mat in_mat = cx_mat(reinterpret_cast<cx_double*>(rho),
                           mat_row, mat_row, false, true);
    cx_mat res = dmqs::ApplyAmplitudeDampeningAndDephasing(in_mat, T1, T2, t);
    memcpy(rho, res.memptr(), mat_size * sizeof(double));
}

// Apply a noise channel to the density matrix.
// See https://link.springer.com/content/pdf/10.1007/s10773-019-04332-z.pdf
// and https://docs.pennylane.ai/en/stable/_modules/pennylane/ops/channel.html
// for details on the implementation of channels.
extern "C" void ApplyChannel(double* rho, int rho_size, int channel,
                              double prob) {
    auto chan = static_cast<u_channel>(channel);
    vector<kraus_t> ops;
    cx_mat res;
    channel_t chan_f = nullptr;
    size_t mat_row = 1 << rho_size;
    size_t mat_size = mat_row * mat_row * 2;
    cx_mat in_mat = cx_mat(reinterpret_cast<cx_double*>(rho),
                           mat_row, mat_row, false, true);
    switch (chan) {
        case AMPLITUDE_DAMPING:
            chan_f = amplitude_damping_ops;
            break;
        case PHASE_DAMPING:
            chan_f = phase_damping_ops;
            break;
        case DEPOLARIZING:
            chan_f = depolarizing_ops;
            break;
        case PHASE_FLIP:
            chan_f = phase_flip_ops;
            break;
        case BIT_PHASE_FLIP:
            chan_f = bit_phase_flip_ops;
            break;
        default:
            throw invalid_argument("Unknown channel type");
    }
    ops = chan_f(prob);
    res = apply_channel(in_mat, ops);
    memcpy(rho, res.memptr(), mat_size * sizeof(double));
}

extern "C" void ApplyGAD(double* rho, int rho_size, double p, double g) {
    size_t mat_row = 1 << rho_size;
    size_t mat_size = mat_row * mat_row * 2;
    cx_mat in_mat = cx_mat(reinterpret_cast<cx_double*>(rho),
                           mat_row, mat_row, false, true);
    cx_mat res = apply_channel(in_mat, generalized_amplitude_damping_ops(p, g));
    memcpy(rho, res.memptr(), mat_size * sizeof(double));
}

model = "/home/uppaal/models/bsdc-density-matrix.xml"
queries = "simulate[<=1000;100] {{(errors+1e-15)/(qubits_sent+1e-15), (errors+1e-15)/(bits_sent+1e-15), (bits_sent+1e-15)/(qubits_sent+1e-15),(bits_sent+1e-15)/(globalTime+1e-15)}}"
experiment_data = "/home/uppaal/data/replication/"
threads = 9
seed = 428094
plots = []
extensions = ["svg"]
vars = {
    'project': {
        'TIMESLOT': 1,
        'bit_stuffing': list(range(0,9)),
        'T1': 20,
        'T2': 18,
    },
    'system': {
        'coding': 'Qstate2(Move, Gen, H, CNOT, Meas, Result, Z, X)',
        'sender': 'SenderTimeslotted(Move, X, Z, H, CNOT, Send, Gen)',
        'receiver': 'ReceiverTimeslotted(Move, H, CNOT, Meas, Result, Rec)',
        'monitor': 'MessageChecker(Send, Rec, Shift, BitStuff)'
    }
}
def get_error_per_bitsuffing(ax, data, TARGET_QUERY_ID = 0, X_OFFSET = 2):
    if len(data) == 0:
        raise ValueError("No experiment data available.")

    print(f"Processing {len(data)} variations for box plots...")

    # Group by timeslot value first
    grouped_data = {}  # key: timeslot value, value: list of last values
    # Process each variation
    for id in data:
        var_group = data[id]
        # Check if successful
        if not var_group.attrs.get('success', False):
            continue

        bitstuffing = get_var_val(var_group, "project", "bit_stuffing")
        
        # Initialize group if not exists
        if bitstuffing not in grouped_data:
            grouped_data[bitstuffing] = []
        # Extract last values from all traces
        data_points = var_group[f'formula_{TARGET_QUERY_ID}']
        for _, points in data_points.items():
            if points:
                try:
                    last_value = float(points[-1][1])
                    grouped_data[bitstuffing].append(last_value)
                except (ValueError, IndexError, TypeError):
                    continue

    # Convert to plot-ready format
    X = []
    Y = []
    #plt.tick_params(labelsize=18)
    for bitstuffing, values in sorted(grouped_data.items()):
        X.append(bitstuffing+X_OFFSET)
        Y.append(values)
    ax.boxplot(Y, tick_labels=X)



def errors_per_bit(ax, data):
    get_error_per_bitsuffing(ax, data, TARGET_QUERY_ID = 1)
    ax.set_title("Errors per Bits Sent")
    ax.set_xlabel("c (Bitstuffing)")
    ax.set_ylabel("Errors / Bits")

def bits_per_qubit(ax, data):
    get_error_per_bitsuffing(ax, data, TARGET_QUERY_ID = 2)
    ax.set_title("Bits per Qubit Sent")
    ax.set_xlabel("c (Bitstuffing)")
    ax.set_ylabel("Bits / Qubits")

def errors_per_qubit(ax, data):
    get_error_per_bitsuffing(ax, data)
    fig = ax.get_figure()
    fig.set_size_inches(4, 3.5)
    ax.set_title("Errors per Qubit Sent")
    ax.set_yticks([0.02, 0.04, 0.06, 0.08, 0.1, 0.12, 0.14])
    ax.set_xlabel("c (Bitstuffing)")
    ax.set_ylabel("Errors / Qubits")

def bits_per_timeslot(ax, data):
    get_error_per_bitsuffing(ax, data, TARGET_QUERY_ID = 3)
    fig = ax.get_figure()
    fig.set_size_inches(4, 2.3)
    ax.set_title("Bits per Timeslot Sent")
    ax.set_yticks([1.3, 1.4, 1.5])
    ax.set_xlabel("c (Bitstuffing)")
    ax.set_ylabel("Bits / Timeslot")

plots.append((errors_per_qubit, {}))
plots.append((errors_per_bit, {}))
plots.append((bits_per_qubit, {}))
plots.append((bits_per_timeslot, {}))
model = "/home/uppaal/models/bsdc-density-matrix.xml"
queries = "simulate[<=fint({project[TIMESLOT]}*1000);100] {{(errors+1e-15)/(bits_sent+1e-15)}}"
experiment_data = "/home/uppaal/data/distillation/"
threads = 10
seed = 8391317
plots = []
extensions = ["svg"]
vars = {
    'project': {
        'TIMESLOT': [0.4, 1, 6, 11, 16, 21, 26, 31, 35,],
        'distil_rounds':[0, 1, 2],
        'bit_stuffing':  [80],
        'gen_error': [0.20],
        'T1': 342.35,
        'T2': 263.65,
        'setup_time': 0,
        'H_time': 0.032,
        'X_time': 0.032,
        'Z_time': 0.032,
        'CNOT_time': 0.138,
        'meas_time': 2.400,
        'generate_time': 0.48,
    },
    'system': {
        'coding': 'Qstate4(Move, Gen, Reset, H, CNOT, Meas, Result, Z, X)',
        'sender': 'SenderShiftingExp(Move, X, Z, H, CNOT, Send, Gen, Shift, BitStuff, Distil, Success, Fail)',
        'receiver': 'Receiver(Move,H, CNOT, Meas, Result, Rec)',
        'distiller': 'Distiller(Distil, Success, Fail, Gen, Reset, H, CNOT, Meas, Result)',
        'monitor': 'Monitor(Send, Rec)'
    } 
}

def create_individual_plot_function(gen_error, TARGET_QUERY_ID=0, name="errors"):
    """
    Create a plotting function for a specific generationError value
    
    Parameters:
    -----------
    gen_error : float
        The generationError value to filter by
    TARGET_QUERY_ID : int
        ID of the query to extract data from
    name : str
        Name for the data being plotted
    """
    def plot_func(ax, data):
        """Plot heatmap for specific generationError value"""
        if not data:
            ax.text(0.5, 0.5, 'No data available', 
                    ha='center', va='center', transform=ax.transAxes)
            ax.set_xticks([])
            ax.set_yticks([])
            return
        
        # Group data by two parameters for this specific generationError
        grouped_data = {}
        
        for id in data:
            var_group = data[id]
            # Check if successful
            if not var_group.attrs.get('success', False):
                continue
            bitstuffing = get_var_val(var_group, "project", "bit_stuffing")

            param_value = get_var_val(var_group, "project", "gen_error")

            if param_value != gen_error:
                continue

            param1_value = get_var_val(var_group, "project", "distil_rounds")
            param2_value = get_var_val(var_group, "project", "TIMESLOT")

            if param2_value >= 40: 
                continue

            key = (param1_value, param2_value)
            
            if key not in grouped_data:
                grouped_data[key] = []

            data_points = var_group[f'formula_{TARGET_QUERY_ID}']
            for _, points in data_points.items():
                if points:
                    try:
                        last_value = float(points[-1][1])
                        grouped_data[key].append(last_value)
                    except (ValueError, IndexError, TypeError):
                        continue
        
        if not grouped_data:
            ax.text(0.5, 0.5, f'No data for generationError={gen_error}', 
                    ha='center', va='center', transform=ax.transAxes)
            ax.set_xticks([])
            ax.set_yticks([])
            return
        
        # Create 2D array for heatmap
        param1_values = sorted(set(k[0] for k in grouped_data.keys()))
        param2_values = sorted(set(k[1] for k in grouped_data.keys()))
        
        # Initialize with NaN for missing combinations
        stats_matrix = np.full((len(param1_values), len(param2_values)), np.nan)
        
        for i, p1 in enumerate(param1_values):
            for j, p2 in enumerate(param2_values):
                key = (p1, p2)
                if key in grouped_data and grouped_data[key]:
                    stats_matrix[i, j] = np.median(grouped_data[key])
        
        # Create heatmap
        fig = ax.get_figure()
        fig.set_size_inches(16, 5)
        plt.tick_params(labelsize=18)
        im = ax.imshow(stats_matrix, cmap='viridis_r', aspect='auto', norm="logit")
        ax.get_figure().supxlabel(f"Generation error {gen_error}", color="black", y=0.92)
        # Add colorbar without name/label
        cbar = plt.colorbar(im, ax=ax)
        cbar.ax.tick_params(labelsize=18)
        # Set ticks and labels
        ax.set_xticks(np.arange(len(param2_values)))
        ax.set_yticks(np.arange(len(param1_values)))
        ax.set_xticklabels(param2_values)
        ax.set_yticklabels(param1_values)
        
        # Rotate x labels if needed
        plt.setp(ax.get_xticklabels(), rotation=45, ha="right", rotation_mode="anchor", fontsize=18)
        
        # Add text annotations
        for i in range(len(param1_values)):
            for j in range(len(param2_values)):
                if not np.isnan(stats_matrix[i, j]):
                    ax.text(j, i, f'{stats_matrix[i, j]:.3f}',
                           ha="center", va="center", color="white",fontsize=18)
        
        ax.set_xlabel("Timeslot length in μs", fontsize=18)
        ax.set_ylabel("Rounds of distillation", fontsize=18)
        
        ax.set_title(f"{name}_{gen_error}", color="white", fontsize=0)
    
    return plot_func


# Create individual plots for each generationError value
plots = []

# Get the generationError values from your vars dictionary
generationError_values = vars['project']['gen_error']

# Create error plots (TARGET_QUERY_ID=0) for each generationError value
for gen_error in generationError_values:
    plot_func = create_individual_plot_function(
        gen_error, 
        TARGET_QUERY_ID=0, 
        name="errors"
    )
    plots.append((plot_func, {}))
# Analysis and Verification of Quantum Communication Protocols in UPPAAL
This folder contains artifacts for "Analysis and Verification of Quantum Communication Protocols in UPPAAL" paper for CAV'26.

## Overview

The folder contains the following artifacts:
- bsdc-enumerated.xml - a full and self-contained BSDC model for 2 qubits with enumerated quantum states
- bsdc-density-matrix.xml - a full BSDC model for 4 qubits with noise and distillation, shifts using density matrices and Armadillo library. The model is polished for readability.
- bsdc-experiments.xml - not so clean version used in experiments.
- dmqs - C++ library linking with Armadillo, required by bsdc-density-matrix.xml and bsdc-experiments.xml.

## Instructions

1. Download and install UPPAAL (either version 5.0 or 5.1) from [UPPAAL.org](https://uppaal.org/downloads/).
You are welcome to use our license key dd5bd740-8262-4fce-b6ee-5b2549c8a3c0
but for the sake of anonymity we suggest you register your own at [veriaal.dk](https://uppaal.veriaal.dk/academic.html)

2. Launch UPPAAL and open bsdc-enumerated.xml, compare with Fig.3

3. 
